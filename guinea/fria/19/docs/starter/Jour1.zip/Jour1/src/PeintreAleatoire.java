import stanford.karel.*;

public class PeintreAleatoire extends SuperKarel {
	
	public void run() {
		// ton code ici...
	}

}
