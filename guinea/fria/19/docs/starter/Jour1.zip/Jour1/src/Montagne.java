import stanford.karel.*;

public class Montagne extends SuperKarel {
	
	public void run() {
		// ton code ici...
	}

}
