import stanford.karel.*;

public class RamasserJournal extends SuperKarel {
	
	public void run(){
		// ton code ici
	}
}
