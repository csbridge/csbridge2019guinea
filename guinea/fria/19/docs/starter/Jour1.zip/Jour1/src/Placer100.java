import stanford.karel.*;

public class Placer100 extends Karel {
	
	public void run() {
		// ton code ici...
	}

}
