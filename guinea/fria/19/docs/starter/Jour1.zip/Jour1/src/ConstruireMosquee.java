import stanford.karel.*;

public class ConstruireMosquee extends SuperKarel {
	
	public void run() {
		// ton code ici...
	}

}
