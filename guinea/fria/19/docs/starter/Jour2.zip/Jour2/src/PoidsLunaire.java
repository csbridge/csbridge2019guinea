import acm.program.ConsoleProgram;


/**
 * Poids lunaire
 * -----
 * Convertis les poids sur terre en poids sur la lune.
 */
public class PoidsLunaire extends ConsoleProgram {

	public void run() {
		// ton code ici ...
	}

}
