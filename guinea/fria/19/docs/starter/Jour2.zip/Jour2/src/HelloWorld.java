import acm.program.ConsoleProgram;

/**
 * Hello World
 * -----
 * Le programme de demarrage classique
 */
public class HelloWorld extends ConsoleProgram {

	public void run() {
		// ton code ici ...
	}

}
