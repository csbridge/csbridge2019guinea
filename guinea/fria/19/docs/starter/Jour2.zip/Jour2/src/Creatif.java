import acm.program.ConsoleProgram;
import acm.util.RandomGenerator;

/**
 * Creatif
 * -----
 * Crée un programme console de ton choix!
 */
public class Creatif extends ConsoleProgram {

	public void run() {
		// ton code ici ...
	}

}
