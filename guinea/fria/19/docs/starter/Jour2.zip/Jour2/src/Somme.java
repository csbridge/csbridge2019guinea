import acm.graphics.*;
import acm.program.*;
import acm.util.RandomGenerator;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

/**
 * Somme
 * -----
 * Ecrire un programme prend en entrée 10 entiers saisis par l’utilisateur 
 * et donne en sortie la somme des valeurs en entrée.
 */
public class Somme extends ConsoleProgram {

	public void run() {
		// ton code ici ...
	}

}
