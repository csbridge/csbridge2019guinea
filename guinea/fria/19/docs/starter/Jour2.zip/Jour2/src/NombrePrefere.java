import acm.program.ConsoleProgram;

/**
 * Favorite Number
 * -----
 * A user tries to guess your favorite number
 */
public class NombrePrefere extends ConsoleProgram {

	// change ceci pour definir ton nombre préféré
	private static final int NOMBRE_PREFERE = 88;
	
	public void run() {
		// ton code ici ...
	}

	
}
