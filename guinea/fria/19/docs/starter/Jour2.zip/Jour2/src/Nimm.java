import acm.graphics.*;
import acm.program.*;
import acm.util.RandomGenerator;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

/**
 * Nimm
 * -----
 * Runs a two player version of the ancient game of Nimm.
 */
public class Nimm extends ConsoleProgram {

	public void run() {
		// ton code ici ...
	}

}
