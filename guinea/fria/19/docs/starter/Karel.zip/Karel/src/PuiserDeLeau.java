import stanford.karel.*;

public class PuiserDeLeau extends SuperKarel {
	
	public void run() {
		// your code here...
	}

}
