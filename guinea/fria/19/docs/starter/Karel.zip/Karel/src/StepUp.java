import stanford.karel.*;

public class StepUp extends SuperKarel {
	
	public void run() {
		// your code here...
	}

}
