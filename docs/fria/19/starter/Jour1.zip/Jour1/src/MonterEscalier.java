import stanford.karel.*;

public class MonterEscalier extends Karel {
	
	public void run() {
		// your code here...
	}

}
