import stanford.karel.*;

public class RamasserJournal extends Karel {
	
	public void run(){
		// ton code ici ...
	}
}
