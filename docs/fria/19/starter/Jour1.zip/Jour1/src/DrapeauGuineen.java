import stanford.karel.*;

public class DrapeauGuineen extends SuperKarel {
	
	public void run() {
		// ton code ici...
	}

}
