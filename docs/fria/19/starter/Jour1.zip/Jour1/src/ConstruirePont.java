import stanford.karel.*;

public class ConstruirePont extends SuperKarel {
	
	public void run() {
		// ton code ici...
	}

}
