import stanford.karel.*;

public class InverserBeepers extends SuperKarel {
	
	public void run() {
		// ton code ici...
	}
}
