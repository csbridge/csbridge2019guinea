import acm.graphics.*;
import acm.program.*;
import acm.util.RandomGenerator;
import java.awt.*;

/**
 * Programmer c'est genial
 * --------------
 * Montre la merveille des graphiques.
 */
public class ProgrammerCestGenial extends GraphicsProgram {
	
	public void run() {
		// ton code ici
	}

}
