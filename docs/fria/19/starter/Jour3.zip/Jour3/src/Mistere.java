import acm.graphics.*;
import acm.program.*;
import acm.util.RandomGenerator;
import java.awt.*;

/**
 * Dessine un carré mystère qui change de couleur
 * -----------------------------------------
 * Fait vraiment ce qu'il dit.
 */
public class Mistere extends GraphicsProgram {

    private static final int SIZE = 400;
    private static final int DELAY = 1000;

    private static RandomGenerator rg = new RandomGenerator();
    
    public void run() {
        // ton code ici
    }
}
