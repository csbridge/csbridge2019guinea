import acm.program.GraphicsProgram;
import acm.graphics.*;

public class Mostiquaire extends GraphicsProgram {

	public void run() {
		// ton code ici ...
	}
	
}