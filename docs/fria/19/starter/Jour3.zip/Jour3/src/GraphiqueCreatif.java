import acm.graphics.*;
import acm.program.*;
import acm.util.RandomGenerator;
import java.awt.*;

public class GraphiqueCreatif extends GraphicsProgram {
	
	public void run() {
		// ton code ici.
		// Tout ce que tu veux!
	}

}
