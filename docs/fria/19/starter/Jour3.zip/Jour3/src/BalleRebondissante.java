import acm.graphics.*;
import acm.program.*;
import acm.util.RandomGenerator;
import java.awt.*;

/**
 * Balle Rebondissante
 * --------------
 * Rebondit une balle partout dans la fenetre.
 */
public class BalleRebondissante extends GraphicsProgram {
	
	public void run() {
		// ton code ici
	}

}
