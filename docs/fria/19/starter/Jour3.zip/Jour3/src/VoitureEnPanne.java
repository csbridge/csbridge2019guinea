import acm.program.GraphicsProgram;

/**
 * Voiture en panne
 * --------------
 * Montre la merveille des graphiques.
 */
public class VoitureEnPanne extends GraphicsProgram {
	
	public void run() {
		// ton code ici
	}

}
